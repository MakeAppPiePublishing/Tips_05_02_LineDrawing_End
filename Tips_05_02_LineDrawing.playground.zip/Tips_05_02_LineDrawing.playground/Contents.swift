import UIKit
import PlaygroundSupport

class View:UIView{
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.frame = frame
        backgroundColor = UIColor(white: 0.85, alpha: 1.0)
        drawLines()
    }
    func drawLines(){
        let drawPoints:[CGPoint] = [CGPoint(x: 300, y:300),CGPoint(x: 300, y: 500),CGPoint(x: 500, y: 500),CGPoint(x: 500, y: 300)]
        let imagerenderer = UIGraphicsImageRenderer(size: frame.size)
        let image = imagerenderer.image(actions:  { (context) in
            //#-editable-code
            //Place drawing code here
            UIColor.brown.setFill()
            UIColor.purple.setStroke()
            context.cgContext.setLineCap(.round)
            context.cgContext.setLineJoin(.round)
            context.cgContext.setLineWidth(10)
            context.cgContext.beginPath()
            context.cgContext.move(to: drawPoints[0])
            context.cgContext.addLine(to: drawPoints[1])
            context.cgContext.addLine(to: drawPoints[2])
            context.cgContext.addLine(to: drawPoints[3])
            context.cgContext.addQuadCurve(to: drawPoints[0], control: CGPoint(x: 400, y: 200))
            context.cgContext.drawPath(using: .fillStroke)
            //#-end-editable-code
        })
        let imageView = UIImageView(image: image)
        addSubview(imageView)
    }
}

PlaygroundPage.current.liveView = View.init(frame: UIScreen.main.bounds)
